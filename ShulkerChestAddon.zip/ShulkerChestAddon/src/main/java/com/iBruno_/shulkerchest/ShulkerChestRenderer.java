package com.iBruno_.shulkerchest;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.client.network.ClientPlayerEntity;
import java.util.List;

public class ShulkerChestRenderer implements WorldRenderEvents.BeforeEntities {
    
    public static void register() {
        WorldRenderEvents.BEFORE_ENTITIES.register(new ShulkerChestRenderer());
    }

    @Override
    public void beforeEntities(WorldRenderContext context) {
        MinecraftClient client