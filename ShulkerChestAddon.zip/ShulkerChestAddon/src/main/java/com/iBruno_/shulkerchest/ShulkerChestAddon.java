package com.iBruno_.shulkerchest;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ShulkerChestAddon implements ModInitializer {
    public static final String MOD_ID = "shulkerchestaddon";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    
    public static KeyBinding toggleKey;
    private static boolean overlayVisible = true;

    @Override
    public void onInitialize() {
        LOGGER.info("ShulkerChestAddon inicializado");
        
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.shulkerchestaddon.toggle",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_H,
            "category.shulkerchestaddon"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                overlayVisible = !overlayVisible;
                LOGGER.info("Overlay " + (overlayVisible ? "visible" : "oculto"));
            }
        });
    }

    public static boolean isOverlayVisible() {
        return overlayVisible;
    }
}