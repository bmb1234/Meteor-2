package com.iBruno_.shulkerchest;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import java.util.ArrayList;
import java.util.List;

public class ShulkerChestFinder {
    private static final int RADIUS = 16;
    private static List<BlockPos> cachedPositions = new ArrayList<>();
    private static long lastUpdateTime = 0;
    private static final long UPDATE_INTERVAL = 1000;

    public static List<BlockPos> findNearbyShulkerBoxes() {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastUpdateTime < UPDATE_INTERVAL) {
            return cachedPositions;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        World world = client.world;
        
        if (player == null || world == null) return new ArrayList<>();

        cachedPositions.clear();
        BlockPos playerPos = player.getBlockPos();

        for (int x = -RADIUS; x <= RADIUS; x++) {
            for (int y = -RADIUS; y <= RADIUS; y++) {
                for (int z = -RADIUS; z <= RADIUS; z++) {
                    BlockPos pos = playerPos.add(x, y, z);
                    BlockState state = world.getBlockState(pos);
                    
                    if (state.getBlock() instanceof ShulkerBoxBlock) {
                        cachedPositions.add(pos);
                    }
                }
            }
        }

        lastUpdateTime = currentTime;
        return cachedPositions;
    }
}